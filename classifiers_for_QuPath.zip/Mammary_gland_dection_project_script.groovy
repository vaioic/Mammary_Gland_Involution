selectAnnotations();
addPixelClassifierMeasurements("Mammary_Duct_Threshold", "Mammary_Duct_Threshold")
